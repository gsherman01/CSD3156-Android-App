# CSD3156-Android-App

# Team id - 14

# Team Members
2301397 Bryan Ang Wei Ze
2303348 Chew Bangxin Steven
2301552 Sam Tsang
2301472 Sherman Goh Wee Hao
2301255 Tham Kang Ting 

Link to GitHub Repo
https://github.com/gsherman01/CSD3156-Android-App
 
 Video Demo  Link (( there is one copy in the repo!))
https://sitsingaporetechedu-my.sharepoint.com/:v:/r/personal/2301472_sit_singaporetech_edu_sg/Documents/CSD3156_id14_TinyCell_VideoDemo.mp4?csf=1&web=1&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJPbmVEcml2ZUZvckJ1c2luZXNzIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXciLCJyZWZlcnJhbFZpZXciOiJNeUZpbGVzTGlua0NvcHkifX0&e=kEv8mn


Presentation Link (( there is one copy in the repo!))
https://sitsingaporetechedu-my.sharepoint.com/:v:/r/personal/2301472_sit_singaporetech_edu_sg/Documents/CSD3156_id14_TinyCell_Presentation.mp4?csf=1&web=1&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJPbmVEcml2ZUZvckJ1c2luZXNzIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXciLCJyZWZlcnJhbFZpZXciOiJNeUZpbGVzTGlua0NvcHkifX0&e=j3yXJO



